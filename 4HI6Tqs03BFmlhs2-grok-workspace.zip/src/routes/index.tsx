import { createFileRoute } from "@tanstack/react-router";
import { SalonApp } from "@/components/salon-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SalonApp />;
}
