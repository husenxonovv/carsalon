import type { InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "flex h-11 w-full rounded-md border border-border bg-elevated px-3 text-base text-fg outline-none transition-colors duration-150 placeholder:text-subtle focus-visible:border-accent",
        className,
      )}
      {...props}
    />
  );
}
