import { Car, LogOut, MapPin, Search } from "lucide-react";
import { useMemo, useState, type FormEvent } from "react";
import { CARS, SALON, type Car as CarModel } from "@/data/cars";
import {
  currentUser,
  loginUser,
  logoutUser,
  registerUser,
  type SalonUser,
} from "@/lib/session";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function SalonApp() {
  const [user, setUser] = useState<SalonUser | null>(() => currentUser());
  const [view, setView] = useState<"cars" | "info">("cars");

  if (!user) {
    return <AuthScreen onLogin={setUser} />;
  }

  return (
    <div className="min-h-screen bg-bg text-fg">
      <header className="sticky top-0 z-20 border-b border-border bg-bg/95">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-lg bg-elevated text-sm font-semibold">
              HA
            </span>
            <div>
              <p className="font-display text-base font-semibold">{SALON.name}</p>
              <p className="text-xs text-muted">{user.name} · {SALON.status}</p>
            </div>
          </div>
          <nav className="flex items-center gap-1">
            <Button
              variant={view === "cars" ? "default" : "ghost"}
              onClick={() => setView("cars")}
              type="button"
            >
              Moshinalar
            </Button>
            <Button
              variant={view === "info" ? "default" : "ghost"}
              onClick={() => setView("info")}
              type="button"
            >
              Ma’lumot
            </Button>
            <Button
              variant="outline"
              type="button"
              onClick={() => {
                logoutUser();
                setUser(null);
              }}
            >
              <LogOut />
              Chiqish
            </Button>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6 pb-16">
        {view === "cars" ? <CarsView /> : <InfoView />}
      </main>
    </div>
  );
}

function AuthScreen({ onLogin }: { onLogin: (user: SalonUser) => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [note, setNote] = useState("");
  const [ok, setOk] = useState(false);

  function submitLogin(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const login = String(data.get("login") ?? "").trim();
    const pass = String(data.get("pass") ?? "");
    const found = loginUser(login, pass);
    if (!found) {
      setOk(false);
      setNote("Foydalanuvchi ma'lumoti topilmadi");
      return;
    }
    onLogin(found);
  }

  function submitRegister(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const result = registerUser({
      name: String(data.get("name") ?? ""),
      login: String(data.get("login") ?? ""),
      pass: String(data.get("pass") ?? ""),
      phone: String(data.get("phone") ?? ""),
    });
    setOk(result === "ok");
    if (result === "empty") setNote("Barcha maydonlarni to‘ldiring");
    else if (result === "short") setNote("Parol kamida 6 ta belgidan iborat bo‘lsin");
    else if (result === "taken") setNote("Bu login band");
    else {
      setNote("Hisob yaratildi. Endi kirishingiz mumkin");
      setMode("login");
    }
  }

  return (
    <div className="grid min-h-screen place-items-center bg-bg px-4 py-8">
      <div className="grid w-full max-w-4xl overflow-hidden rounded-xl border border-border bg-surface md:grid-cols-[1.1fr_0.9fr]">
        <section className="hidden border-r border-border p-8 md:block">
          <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">
            Rasmiy avtosalon
          </p>
          <h1 className="font-display mt-2 text-4xl font-semibold tracking-tight">
            {SALON.name}
          </h1>
          <p className="mt-3 max-w-sm leading-normal text-muted">
            20 ta O‘zbekiston modeli. Kirgach, moshina kartasini bosing — yili va
            ishlab chiqarilgan soni ochiladi.
          </p>
          <dl className="mt-8 grid grid-cols-3 gap-2">
            <div className="rounded-lg bg-elevated p-3">
              <dt className="text-xs text-muted">Modellar</dt>
              <dd className="text-xl font-semibold">20</dd>
            </div>
            <div className="rounded-lg bg-elevated p-3">
              <dt className="text-xs text-muted">Manzil</dt>
              <dd className="text-xl font-semibold">Toshkent</dd>
            </div>
            <div className="rounded-lg bg-elevated p-3">
              <dt className="text-xs text-muted">Ish vaqti</dt>
              <dd className="text-xl font-semibold">09–19</dd>
            </div>
          </dl>
        </section>
        <section className="p-6 sm:p-8">
          <div className="mb-5 flex gap-2">
            <Button
              type="button"
              variant={mode === "login" ? "default" : "ghost"}
              onClick={() => {
                setMode("login");
                setNote("");
              }}
            >
              Kirish
            </Button>
            <Button
              type="button"
              variant={mode === "register" ? "default" : "ghost"}
              onClick={() => {
                setMode("register");
                setNote("");
              }}
            >
              Hisob yaratish
            </Button>
          </div>
          {mode === "login" ? (
            <form className="grid gap-3" onSubmit={submitLogin}>
              <div className="grid gap-1.5">
                <Label htmlFor="login-user">Login</Label>
                <Input
                  id="login-user"
                  name="login"
                  autoComplete="username"
                  placeholder="Loginni kiriting"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="login-pass">Parol</Label>
                <Input
                  id="login-pass"
                  name="pass"
                  type="password"
                  autoComplete="current-password"
                  placeholder="Parolni kiriting"
                />
              </div>
              <Button type="submit" size="lg" className="mt-2">
                Salonga kirish
              </Button>
              {note ? (
                <p className={ok ? "text-sm text-ok" : "text-sm text-danger"}>{note}</p>
              ) : (
                <p className="text-sm text-muted">
                  Hisobingiz bo‘lmasa, “Hisob yaratish” tugmasini bosing.
                </p>
              )}
            </form>
          ) : (
            <form className="grid gap-3" onSubmit={submitRegister}>
              <div className="grid gap-1.5">
                <Label htmlFor="reg-name">Ism</Label>
                <Input id="reg-name" name="name" />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="reg-user">Login</Label>
                <Input id="reg-user" name="login" />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="reg-pass">Parol</Label>
                <Input id="reg-pass" name="pass" type="password" />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="reg-phone">Telefon</Label>
                <Input id="reg-phone" name="phone" />
              </div>
              <Button type="submit" size="lg" className="mt-2">
                Hisob yaratish
              </Button>
              {note ? (
                <p className={ok ? "text-sm text-ok" : "text-sm text-danger"}>{note}</p>
              ) : null}
            </form>
          )}
        </section>
      </div>
    </div>
  );
}

function CarsView() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<CarModel | null>(null);
  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return CARS;
    return CARS.filter((car) =>
      `${car.name} ${car.kind} ${car.place}`.toLowerCase().includes(q),
    );
  }, [query]);

  return (
    <div>
      <section className="rounded-xl border border-border bg-surface p-5">
        <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">
          Qanday ochiladi
        </p>
        <h2 className="font-display mt-1 text-3xl font-semibold tracking-tight">
          Moshina kartasini bosing
        </h2>
        <p className="mt-2 max-w-2xl leading-normal text-muted">
          Har bir kartadagi <span className="text-fg">Moshina haqida ochish</span>{" "}
          tugmasi yilini va nechta ishlab chiqarilganini ko‘rsatadi.
        </p>
        <div className="relative mt-4 max-w-md">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
          <Input
            className="pl-10"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Model qidirish: Cobalt, Damas..."
          />
        </div>
      </section>

      <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((car, index) => (
          <article
            key={car.id}
            className="flex min-h-56 flex-col rounded-xl border border-border bg-surface p-4"
          >
            <div className="mb-4 flex items-center justify-between rounded-lg bg-elevated px-3 py-4">
              <span className="text-sm text-muted">{String(index + 1).padStart(2, "0")}</span>
              <Car className="size-6 text-fg" />
              <span className="text-sm text-muted">{car.kind}</span>
            </div>
            <h3 className="font-display text-lg font-semibold">{car.name}</h3>
            <p className="mt-1 flex-1 text-sm text-muted">{car.year}</p>
            <Button type="button" className="mt-4 w-full" onClick={() => setSelected(car)}>
              Moshina haqida ochish
            </Button>
          </article>
        ))}
      </div>

      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent>
          {selected ? (
            <>
              <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">
                {selected.kind}
              </p>
              <DialogTitle>{selected.name}</DialogTitle>
              <DialogDescription>{selected.about}</DialogDescription>
              <dl className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2">
                <Fact label="Paydo bo‘lgan yili" value={selected.year} />
                <Fact label="Ishlab chiqarilgani" value={selected.produced} />
                <Fact label="Salon narxi" value={selected.price} />
                <Fact label="O‘rni" value={selected.place} />
              </dl>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-elevated p-3">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="mt-1 text-sm font-medium">{value}</dd>
    </div>
  );
}

function InfoView() {
  const rows = [
    ["Salon nomi", SALON.name],
    ["Maqomi", SALON.status],
    ["Manzil", SALON.address],
    ["Mavjud moshinalar", `${SALON.cars} ta model`],
    ["Ish vaqti", SALON.hours],
    ["Telefon", SALON.phone],
  ] as const;

  return (
    <section className="grid gap-3 lg:grid-cols-[1.1fr_0.9fr]">
      <article className="rounded-xl border border-border bg-surface p-5">
        <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">
          Ma’lumot bo‘limi
        </p>
        <h2 className="font-display mt-1 text-3xl font-semibold tracking-tight">Salon haqida</h2>
        <div className="mt-4">
          {rows.map(([label, value]) => (
            <div
              key={label}
              className="flex flex-col gap-1 border-b border-border py-3 last:border-b-0 sm:flex-row sm:justify-between sm:gap-6"
            >
              <span className="text-sm text-muted">{label}</span>
              <span className="text-sm font-medium sm:text-right">{value}</span>
            </div>
          ))}
        </div>
      </article>
      <article className="rounded-xl border border-border bg-surface p-5">
        <MapPin className="size-5 text-muted" />
        <h3 className="font-display mt-3 text-xl font-semibold">Toshkent shourumi</h3>
        <p className="mt-2 leading-normal text-muted">{SALON.address}</p>
        <p className="mt-4 leading-normal text-muted">
          Katalogdagi ishlab chiqarish sonlari ochiq statistika asosida taxminiy
          jamlangan. Aniq shartnoma narxi salonda yangilanadi.
        </p>
      </article>
    </section>
  );
}
