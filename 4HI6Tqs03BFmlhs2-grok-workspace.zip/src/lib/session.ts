export type SalonUser = {
  name: string;
  login: string;
  pass: string;
  phone: string;
};

const USERS_KEY = "ha-users";
const SESSION_KEY = "ha-session";

export const DEFAULT_USER: SalonUser = {
  name: "Husenxonov",
  login: "husenxonov",
  pass: "husenxonov00001",
  phone: "+998",
};

function readUsers(): SalonUser[] {
  if (typeof window === "undefined") return [DEFAULT_USER];
  const raw = localStorage.getItem(USERS_KEY);
  if (!raw) {
    localStorage.setItem(USERS_KEY, JSON.stringify([DEFAULT_USER]));
    return [DEFAULT_USER];
  }
  try {
    const parsed = JSON.parse(raw) as SalonUser[];
    if (!Array.isArray(parsed) || parsed.length === 0) return [DEFAULT_USER];
    return parsed;
  } catch {
    return [DEFAULT_USER];
  }
}

export function loginUser(login: string, pass: string): SalonUser | null {
  const found = readUsers().find((u) => u.login === login && u.pass === pass);
  if (!found) return null;
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(found));
  return found;
}

export function registerUser(user: SalonUser): "ok" | "taken" | "empty" | "short" {
  if (!user.name.trim() || !user.login.trim() || !user.pass || !user.phone.trim()) {
    return "empty";
  }
  if (user.pass.length < 6) return "short";
  const list = readUsers();
  if (list.some((u) => u.login === user.login.trim())) return "taken";
  list.push({
    name: user.name.trim(),
    login: user.login.trim(),
    pass: user.pass,
    phone: user.phone.trim(),
  });
  localStorage.setItem(USERS_KEY, JSON.stringify(list));
  return "ok";
}

export function currentUser(): SalonUser | null {
  if (typeof window === "undefined") return null;
  const raw = sessionStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as SalonUser;
  } catch {
    return null;
  }
}

export function logoutUser() {
  sessionStorage.removeItem(SESSION_KEY);
}
