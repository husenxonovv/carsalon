import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as LogOut, i as MapPin, o as Car, r as Search, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, i as DialogDescription$1, l as Slot, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CsZ8QCeR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CARS = [
	{
		id: "cobalt",
		name: "Chevrolet Cobalt",
		year: "2012-yildan (O‘zbekistonda)",
		produced: "1 000 000 dan ortiq",
		price: "145 000 000 so‘m",
		place: "Asaka zavodi",
		kind: "Sedan",
		about: "Oilaviy sedan. 2020-yildan beri O‘zbekistonda eng ko‘p ishlab chiqarilgan yengil model. 2024-yilda 164 887 dona, 2025-yilda 161 152 dona yig‘ilgan."
	},
	{
		id: "damas",
		name: "Chevrolet Damas",
		year: "1996-yildan",
		produced: "1 200 000 ga yaqin",
		price: "98 000 000 so‘m",
		place: "Pitnak / Xorazm filiali",
		kind: "Mini ven",
		about: "Shaharcha va kichik biznes uchun mashhur mikroavtobus. So‘nggi yillarda yiliga taxminan 50–100 ming dona atrofida yig‘iladi."
	},
	{
		id: "labo",
		name: "Chevrolet Labo",
		year: "1996–2004 va 2015-yildan",
		produced: "400 000 dan ortiq",
		price: "102 000 000 so‘m",
		place: "Pitnak / Xorazm filiali",
		kind: "Yuk mashinasi",
		about: "Damas asosidagi kichik yuk avtomobili. 2015-yilda yig‘ish qayta tiklangan."
	},
	{
		id: "tracker",
		name: "Chevrolet Tracker",
		year: "2018-yildan, yangi avlod 2022",
		produced: "180 000 ga yaqin",
		price: "228 000 000 so‘m",
		place: "Asaka zavodi",
		kind: "Krossover",
		about: "Yangi avlod Tracker 2022-yildan mahalliy katalogda. 2024-yilda 45 918, 2025-yilda 50 362 dona ishlab chiqarilgan."
	},
	{
		id: "onix",
		name: "Chevrolet Onix",
		year: "2023-yildan",
		produced: "70 000 dan ortiq",
		price: "168 000 000 so‘m",
		place: "Asaka zavodi",
		kind: "Sedan",
		about: "2023-yilda liniyaga qo‘shilgan ixcham sedan. 2026-yilning yanvar–iyul oylarida 20 445 dona qayd etilgan."
	},
	{
		id: "gentra",
		name: "Chevrolet Gentra",
		year: "2013–2024",
		produced: "700 000 ga yaqin",
		price: "152 000 000 so‘m",
		place: "Asaka zavodi",
		kind: "Sedan",
		about: "Lacetti platformasidagi sedan. Ayrim yillarda Ravon Gentra nomi bilan ham sotilgan. 2022-yilda 87 105, 2023-yilda 82 133 dona."
	},
	{
		id: "nexia3",
		name: "Chevrolet Nexia 3",
		year: "2015–2023",
		produced: "450 000 ga yaqin",
		price: "Katalogdan chiqqan",
		place: "Asaka zavodi",
		kind: "Sedan",
		about: "Ichki bozorda Nexia 3. 2017–2019-yillarda ishlab chiqarish bo‘yicha birinchi o‘rinda bo‘lgan."
	},
	{
		id: "nexia",
		name: "Daewoo Nexia",
		year: "1996–2008",
		produced: "600 000 dan ortiq",
		price: "Tarixiy model",
		place: "Asaka zavodi",
		kind: "Sedan",
		about: "Zavodning birinchi ommaviy sedani. 2000-yillar boshida yiliga 80 mingdan ortiq dona yig‘ilgan yillar bo‘lgan."
	},
	{
		id: "nexia2",
		name: "Daewoo Nexia II",
		year: "2008–2016",
		produced: "400 000 ga yaqin",
		price: "Tarixiy model",
		place: "Asaka zavodi",
		kind: "Sedan",
		about: "Yangilangan Nexia. 2010–2012 va 2015–2016-yillarda ishlab chiqarish yetakchilari qatorida turgan."
	},
	{
		id: "spark",
		name: "Chevrolet Spark",
		year: "2010–2023",
		produced: "350 000 ga yaqin",
		price: "Katalogdan chiqqan",
		place: "Asaka zavodi",
		kind: "Shaharcha",
		about: "2015-yildan ayrim bozorlarda Ravon R2 nomi bilan chiqqan. 2016–2017-yillarda yiliga 17–22 ming dona atrofida yig‘ilgan."
	},
	{
		id: "matiz",
		name: "Ravon Matiz",
		year: "2001–2018",
		produced: "700 000 ga yaqin",
		price: "Tarixiy model",
		place: "Asaka zavodi",
		kind: "Shaharcha",
		about: "Dastlab Daewoo Matiz. 2010–2012-yillarda yiliga 55–73 ming dona ishlab chiqarilgan."
	},
	{
		id: "orlando",
		name: "Chevrolet Orlando",
		year: "2014–2018",
		produced: "40 000 ga yaqin",
		price: "Tarixiy model",
		place: "Xorazm filiali",
		kind: "7 o‘rindiqli",
		about: "Oilaviy kompaktven. O‘zbekistonda 2014–2018-yillarda yig‘ilgan."
	},
	{
		id: "captiva",
		name: "Chevrolet Captiva",
		year: "Katalogda 2010-yillardan",
		produced: "Import va yig‘uv partiyalari",
		price: "285 000 000 so‘m",
		place: "Rasmiy yetkazish",
		kind: "Yo‘ltanlamas",
		about: "Rasmiy qatordagi oilaviy yo‘ltanlamas."
	},
	{
		id: "malibu",
		name: "Chevrolet Malibu XL",
		year: "2018-yildan yetkaziladi",
		produced: "Import partiyalari",
		price: "365 000 000 so‘m",
		place: "Rasmiy import",
		kind: "Biznes sedan",
		about: "9-avlodi 2018-yildan rasmiy qatorda."
	},
	{
		id: "equinox",
		name: "Chevrolet Equinox",
		year: "2020-yildan",
		produced: "Import partiyalari",
		price: "398 000 000 so‘m",
		place: "Rasmiy import",
		kind: "O‘rta SUV",
		about: "2020-yilda rasmiy import qatoriga qo‘shilgan."
	},
	{
		id: "traverse",
		name: "Chevrolet Traverse",
		year: "2020-yildan",
		produced: "Import partiyalari",
		price: "620 000 000 so‘m",
		place: "Rasmiy import",
		kind: "Katta krossover",
		about: "Uch qatorli oilaviy model."
	},
	{
		id: "tahoe",
		name: "Chevrolet Tahoe",
		year: "2020-yildan",
		produced: "Import partiyalari",
		price: "980 000 000 so‘m",
		place: "Rasmiy import",
		kind: "To‘liq o‘lcham",
		about: "5-avlod Tahoe rasmiy salonda katta yo‘ltanlamas sifatida turadi."
	},
	{
		id: "trailblazer",
		name: "Chevrolet Trailblazer",
		year: "2020-yildan",
		produced: "Import partiyalari",
		price: "340 000 000 so‘m",
		place: "Rasmiy import",
		kind: "SUV",
		about: "2-avlod yangilangan Trailblazer. 2020-yildan rasmiy yetkazib berish ro‘yxatida."
	},
	{
		id: "tico",
		name: "Daewoo Tico",
		year: "1996–2003",
		produced: "150 000 ga yaqin",
		price: "Tarixiy model",
		place: "Asaka zavodi",
		kind: "Birinchi to‘lqin",
		about: "Zavod ochilgan davrdagi eng kichik shahar avtomobili. 2003-yilda yig‘ish to‘xtagan."
	},
	{
		id: "lacetti",
		name: "Chevrolet Lacetti",
		year: "2003–2013",
		produced: "300 000 ga yaqin",
		price: "Tarixiy model",
		place: "Asaka zavodi",
		kind: "Sedan",
		about: "Gentra’dan oldingi avlod. Keyinroq Gentra bilan almashgan."
	}
];
var SALON = {
	name: "Husenxonov Avtosalon",
	status: "Rasmiy avtosalon",
	address: "Toshkent sh., Yunusobod tumani, Amir Temur shoh ko‘chasi, 107-uy",
	cars: 20,
	hours: "Dushanba–shanba, 09:00–19:00",
	phone: "+998 71 200 00 01"
};
var USERS_KEY = "ha-users";
var SESSION_KEY = "ha-session";
var DEFAULT_USER = {
	name: "Husenxonov",
	login: "husenxonov",
	pass: "husenxonov00001",
	phone: "+998"
};
function readUsers() {
	if (typeof window === "undefined") return [DEFAULT_USER];
	const raw = localStorage.getItem(USERS_KEY);
	if (!raw) {
		localStorage.setItem(USERS_KEY, JSON.stringify([DEFAULT_USER]));
		return [DEFAULT_USER];
	}
	try {
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed) || parsed.length === 0) return [DEFAULT_USER];
		return parsed;
	} catch {
		return [DEFAULT_USER];
	}
}
function loginUser(login, pass) {
	const found = readUsers().find((u) => u.login === login && u.pass === pass);
	if (!found) return null;
	sessionStorage.setItem(SESSION_KEY, JSON.stringify(found));
	return found;
}
function registerUser(user) {
	if (!user.name.trim() || !user.login.trim() || !user.pass || !user.phone.trim()) return "empty";
	if (user.pass.length < 6) return "short";
	const list = readUsers();
	if (list.some((u) => u.login === user.login.trim())) return "taken";
	list.push({
		name: user.name.trim(),
		login: user.login.trim(),
		pass: user.pass,
		phone: user.phone.trim()
	});
	localStorage.setItem(USERS_KEY, JSON.stringify(list));
	return "ok";
}
function currentUser() {
	if (typeof window === "undefined") return null;
	const raw = sessionStorage.getItem(SESSION_KEY);
	if (!raw) return null;
	try {
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function logoutUser() {
	sessionStorage.removeItem(SESSION_KEY);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-opacity duration-150 disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			outline: "border border-border bg-transparent text-fg hover:bg-elevated",
			ghost: "text-muted hover:bg-elevated hover:text-fg"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 px-3",
			lg: "h-12 min-h-12 px-5 text-base"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var Dialog = Dialog$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-bg/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(36rem,calc(100%-1.5rem))] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-surface p-5 shadow-lg outline-none", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				size: "sm",
				className: "absolute top-3 right-3",
				type: "button",
				children: ["Yopish", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})]
			})
		})]
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display pr-20 text-2xl font-semibold tracking-tight text-fg", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-2 text-sm leading-normal text-muted", className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md border border-border bg-elevated px-3 text-base text-fg outline-none transition-colors duration-150 placeholder:text-subtle focus-visible:border-accent", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-sm font-medium text-muted", className),
		...props
	});
}
function SalonApp() {
	const [user, setUser] = (0, import_react.useState)(() => currentUser());
	const [view, setView] = (0, import_react.useState)("cars");
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthScreen, { onLogin: setUser });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-border bg-bg/95",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 place-items-center rounded-lg bg-elevated text-sm font-semibold",
						children: "HA"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-base font-semibold",
						children: SALON.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							user.name,
							" · ",
							SALON.status
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: view === "cars" ? "default" : "ghost",
							onClick: () => setView("cars"),
							type: "button",
							children: "Moshinalar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: view === "info" ? "default" : "ghost",
							onClick: () => setView("info"),
							type: "button",
							children: "Ma’lumot"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							type: "button",
							onClick: () => {
								logoutUser();
								setUser(null);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {}), "Chiqish"]
						})
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto max-w-6xl px-4 py-6 pb-16",
			children: view === "cars" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarsView, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoView, {})
		})]
	});
}
function AuthScreen({ onLogin }) {
	const [mode, setMode] = (0, import_react.useState)("login");
	const [note, setNote] = (0, import_react.useState)("");
	const [ok, setOk] = (0, import_react.useState)(false);
	function submitLogin(e) {
		e.preventDefault();
		const data = new FormData(e.currentTarget);
		const found = loginUser(String(data.get("login") ?? "").trim(), String(data.get("pass") ?? ""));
		if (!found) {
			setOk(false);
			setNote("Foydalanuvchi ma'lumoti topilmadi");
			return;
		}
		onLogin(found);
	}
	function submitRegister(e) {
		e.preventDefault();
		const data = new FormData(e.currentTarget);
		const result = registerUser({
			name: String(data.get("name") ?? ""),
			login: String(data.get("login") ?? ""),
			pass: String(data.get("pass") ?? ""),
			phone: String(data.get("phone") ?? "")
		});
		setOk(result === "ok");
		if (result === "empty") setNote("Barcha maydonlarni to‘ldiring");
		else if (result === "short") setNote("Parol kamida 6 ta belgidan iborat bo‘lsin");
		else if (result === "taken") setNote("Bu login band");
		else {
			setNote("Hisob yaratildi. Endi kirishingiz mumkin");
			setMode("login");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-bg px-4 py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid w-full max-w-4xl overflow-hidden rounded-xl border border-border bg-surface md:grid-cols-[1.1fr_0.9fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "hidden border-r border-border p-8 md:block",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.16em] text-muted uppercase",
						children: "Rasmiy avtosalon"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-2 text-4xl font-semibold tracking-tight",
						children: SALON.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm leading-normal text-muted",
						children: "20 ta O‘zbekiston modeli. Kirgach, moshina kartasini bosing — yili va ishlab chiqarilgan soni ochiladi."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-8 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-elevated p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted",
									children: "Modellar"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "text-xl font-semibold",
									children: "20"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-elevated p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted",
									children: "Manzil"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "text-xl font-semibold",
									children: "Toshkent"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-elevated p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted",
									children: "Ish vaqti"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "text-xl font-semibold",
									children: "09–19"
								})]
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "p-6 sm:p-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: mode === "login" ? "default" : "ghost",
						onClick: () => {
							setMode("login");
							setNote("");
						},
						children: "Kirish"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: mode === "register" ? "default" : "ghost",
						onClick: () => {
							setMode("register");
							setNote("");
						},
						children: "Hisob yaratish"
					})]
				}), mode === "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: submitLogin,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "login-user",
								children: "Login"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "login-user",
								name: "login",
								autoComplete: "username",
								placeholder: "Loginni kiriting"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "login-pass",
								children: "Parol"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "login-pass",
								name: "pass",
								type: "password",
								autoComplete: "current-password",
								placeholder: "Parolni kiriting"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "lg",
							className: "mt-2",
							children: "Salonga kirish"
						}),
						note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: ok ? "text-sm text-ok" : "text-sm text-danger",
							children: note
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Hisobingiz bo‘lmasa, “Hisob yaratish” tugmasini bosing."
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: submitRegister,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "reg-name",
								children: "Ism"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "reg-name",
								name: "name"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "reg-user",
								children: "Login"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "reg-user",
								name: "login"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "reg-pass",
								children: "Parol"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "reg-pass",
								name: "pass",
								type: "password"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "reg-phone",
								children: "Telefon"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "reg-phone",
								name: "phone"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "lg",
							className: "mt-2",
							children: "Hisob yaratish"
						}),
						note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: ok ? "text-sm text-ok" : "text-sm text-danger",
							children: note
						}) : null
					]
				})]
			})]
		})
	});
}
function CarsView() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [selected, setSelected] = (0, import_react.useState)(null);
	const list = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (!q) return CARS;
		return CARS.filter((car) => `${car.name} ${car.kind} ${car.place}`.toLowerCase().includes(q));
	}, [query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-xl border border-border bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.16em] text-muted uppercase",
					children: "Qanday ochiladi"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-1 text-3xl font-semibold tracking-tight",
					children: "Moshina kartasini bosing"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 max-w-2xl leading-normal text-muted",
					children: [
						"Har bir kartadagi ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "Moshina haqida ochish"
						}),
						" ",
						"tugmasi yilini va nechta ishlab chiqarilganini ko‘rsatadi."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mt-4 max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "pl-10",
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "Model qidirish: Cobalt, Damas..."
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3",
			children: list.map((car, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "flex min-h-56 flex-col rounded-xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between rounded-lg bg-elevated px-3 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: String(index + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, { className: "size-6 text-fg" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: car.kind
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg font-semibold",
						children: car.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 flex-1 text-sm text-muted",
						children: car.year
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						className: "mt-4 w-full",
						onClick: () => setSelected(car),
						children: "Moshina haqida ochish"
					})
				]
			}, car.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!selected,
			onOpenChange: (open) => !open && setSelected(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.16em] text-muted uppercase",
					children: selected.kind
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: selected.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: selected.about }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
							label: "Paydo bo‘lgan yili",
							value: selected.year
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
							label: "Ishlab chiqarilgani",
							value: selected.produced
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
							label: "Salon narxi",
							value: selected.price
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
							label: "O‘rni",
							value: selected.place
						})
					]
				})
			] }) : null })
		})
	] });
}
function Fact({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-elevated p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 text-sm font-medium",
			children: value
		})]
	});
}
function InfoView() {
	const rows = [
		["Salon nomi", SALON.name],
		["Maqomi", SALON.status],
		["Manzil", SALON.address],
		["Mavjud moshinalar", `${SALON.cars} ta model`],
		["Ish vaqti", SALON.hours],
		["Telefon", SALON.phone]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid gap-3 lg:grid-cols-[1.1fr_0.9fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-xl border border-border bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.16em] text-muted uppercase",
					children: "Ma’lumot bo‘limi"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-1 text-3xl font-semibold tracking-tight",
					children: "Salon haqida"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: rows.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1 border-b border-border py-3 last:border-b-0 sm:flex-row sm:justify-between sm:gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium sm:text-right",
							children: value
						})]
					}, label))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-xl border border-border bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5 text-muted" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display mt-3 text-xl font-semibold",
					children: "Toshkent shourumi"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 leading-normal text-muted",
					children: SALON.address
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 leading-normal text-muted",
					children: "Katalogdagi ishlab chiqarish sonlari ochiq statistika asosida taxminiy jamlangan. Aniq shartnoma narxi salonda yangilanadi."
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalonApp, {});
}
//#endregion
export { Home as component };
