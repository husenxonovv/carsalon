//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C2iz8VBu.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DN_hIUwo.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DN_hIUwo.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-QTl35iUj.js"]
	}
} });
//#endregion
export { tsrStartManifest };
